# test_Boston_Roads_network.py

import pytest
import os
from Boston_Roads_networks import plot_boston_roads_network
from CityInsight.Boston_Roads_networks import plot_boston_roads_network
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from Boston_Roads_networks import plot_boston_roads_network


def test_boston_roads_network_plot():
    # Test if the plot is being saved
    plot_boston_roads_network()  # Call the function from Boston_Roads_networks.py

    # Check if the plot file is saved correctly
    assert os.path.exists('boston_roads_parks_libraries.png'), "Plot file was not created"

# To run the test with pytest, you can execute the command `pytest` in your terminal
